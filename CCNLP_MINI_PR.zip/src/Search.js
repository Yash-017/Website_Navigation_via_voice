import React from "react"
import { Link } from "react-router-dom"
import "./pg.css"
export function Search() {
  
  return (
    <div className="sty">
      Search For AudioBook
      <br></br>
      <br></br>
      <br></br>
      <Link to="/" className="a">Go Back To Home Page</Link>
      </div>
    
  )
}

export default Search